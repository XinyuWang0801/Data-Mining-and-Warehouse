def spectral_clustering(G): # do not change the heading of the function
    pass # **replace** this line with your code
